package encapsulamiento;

public class Persona {
    public String nombre;
    public int edad;
    public long documentoId;

    public Persona(String nombre, int edad, long documentoId) {
        this.nombre = nombre;
        this.edad = edad;
        this.documentoId = documentoId;
    }
}
