/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encapsulamiento;

import java.util.Scanner;

/**
 *
 * @author Sala 101
 */
public class Encapsulamiento {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Persona pepito = new Persona("Pepito Perez", 18, 103695);
        Persona juanita = pepito;
        juanita.nombre = "Juanita Alimaña";
        juanita.edad = 35;
        juanita.documentoId = 45896;


        System.out.println("Nombre Pepito: " + pepito.nombre);
        System.out.println("Edad Pepito: " + pepito.edad);
        System.out.println("Documento Pepito: " + pepito.documentoId);

        System.out.println("Nombre Juanita: " + juanita.nombre);
        System.out.println("Edad Juanita: " + juanita.edad);
        System.out.println("Documento Juanita: " + juanita.documentoId);
    }
    
}
