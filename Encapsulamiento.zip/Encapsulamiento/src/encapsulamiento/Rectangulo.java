/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package encapsulamiento;

/**
 *
 * @author Sala 101
 */
public class Rectangulo {
    
    public Rectangulo(double base, double altura)
    {
        this.base = base;
        this.altura = altura;
    }
    
    private double base;
    private double altura; 
    
    public void setBase(double newBase)
    {
        base = newBase;
    }
    
    public void setAltura(double newAltura)
    {
        altura = newAltura;
    }

    public double CalcularArea()
    {
        return base * altura;
    }
    
    public double CalcularPerimetro()
    {
        return 2 * (base + altura);
    }
}
